from django.db import models
from django.contrib.auth.models import User

class Business(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class FAQ(models.Model):
    business = models.ForeignKey(Business, on_delete=models.CASCADE, related_name='faqs')
    question = models.TextField()
    answer = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.question


class ChatbotSetting(models.Model):
    business = models.OneToOneField(Business, on_delete=models.CASCADE, related_name='settings')
    greeting_message = models.CharField(max_length=500, default="Hello! How can I assist you today?")
    theme_color = models.CharField(max_length=20, default="#007bff")  # Hex color
    enable_suggestions = models.BooleanField(default=True)

    def __str__(self):
        return f'Settings for {self.business.name}'
