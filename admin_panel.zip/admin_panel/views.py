from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import FAQ, ChatbotSetting
from .forms import FAQForm, ChatbotSettingForm

@login_required
def admin_dashboard(request):
    return render(request, 'adminpanel/dashboard.html')

@login_required
def manage_faqs(request):
    faqs = FAQ.objects.filter(business=request.user.business)
    return render(request, 'adminpanel/manage_faqs.html', {'faqs': faqs})

@login_required
def chatbot_settings(request):
    settings = ChatbotSetting.objects.get(business=request.user.business)
    return render(request, 'adminpanel/chatbot_settings.html', {'settings': settings})
