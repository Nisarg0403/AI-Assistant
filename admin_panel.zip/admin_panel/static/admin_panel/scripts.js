document.addEventListener("DOMContentLoaded", function() {
    console.log("Admin panel loaded.");
});
