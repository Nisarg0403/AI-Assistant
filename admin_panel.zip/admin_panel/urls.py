from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('manage-faqs/', views.manage_faqs, name='manage_faqs'),
    path('chatbot-settings/', views.chatbot_settings, name='chatbot_settings'),
]
