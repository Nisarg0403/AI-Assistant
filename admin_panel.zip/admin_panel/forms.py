from django import forms
from .models import FAQ, ChatbotSetting

class FAQForm(forms.ModelForm):
    class Meta:
        model = FAQ
        fields = ['question', 'answer']

class ChatbotSettingForm(forms.ModelForm):
    class Meta:
        model = ChatbotSetting
        fields = ['greeting_message', 'theme_color', 'enable_suggestions']
