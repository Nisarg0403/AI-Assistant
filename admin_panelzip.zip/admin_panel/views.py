from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .models import FAQ, ChatbotTheme
from django.http import HttpResponse, JsonResponse
from django.urls import reverse

def dashboard_view(request):
    return render(request, 'admin_panel/dashboard.html')
def manage_faqs(request):
    if request.method == 'POST':
        # Handle the addition of a new FAQ
        question = request.POST.get('faq_question')
        answer = request.POST.get('faq_answer')
        FAQ.objects.create(question=question, answer=answer)
        return redirect('admin_panel:manage_faqs')

    # Retrieve all FAQs to display on the page
    faqs = FAQ.objects.all()
    return render(request, 'admin_panel/manage_faqs.html', {'faqs': faqs})

def edit_faq(request):
    if request.method == 'POST':
        faq_id = request.POST.get('faq_id')
        question = request.POST.get('faq_question')
        answer = request.POST.get('faq_answer')

        faq = FAQ.objects.get(id=faq_id)
        faq.question = question
        faq.answer = answer
        faq.save()

        return redirect('admin_panel:manage_faqs')

def delete_faq(request, faq_id):
    faq = FAQ.objects.get(id=faq_id)
    faq.delete()
    return redirect('admin_panel:manage_faqs')


# View to fetch current theme settings
def get_theme_settings(request):
    theme = ChatbotTheme.objects.first()  # Assuming only one default theme
    if theme:
        theme_data = {
            'primary_background_color': theme.primary_background_color,
            'secondary_background_color': theme.secondary_background_color,
            'nav_background_color': theme.nav_background_color,
            'text_color': theme.text_color,
            'accent_color': theme.accent_color,
            'user_message_color': theme.user_message_color,
            'bot_message_color': theme.bot_message_color,
            'bot_icon_background_color': theme.bot_icon_background_color,
            'gradient_start_color': theme.gradient_start_color,
            'gradient_end_color': theme.gradient_end_color,
            'font_family': theme.font_family,
            'navbar_text_color': theme.navbar_text_color,
            'button_padding': theme.button_padding,
            'button_border_radius': theme.button_border_radius,
            'button_font_size': theme.button_font_size,
            'message_animation_duration': theme.message_animation_duration,
            'message_icon_size': theme.message_icon_size,
            'suggestion_button_padding': theme.suggestion_button_padding,
            'suggestion_button_border_radius': theme.suggestion_button_border_radius,
        }
        return JsonResponse(theme_data)
    return JsonResponse({'error': 'Theme not found'}, status=404)

# View to update theme settings (admin only)
def update_theme_settings(request):
    if request.method == 'POST':
        theme = ChatbotTheme.objects.first()
        theme.primary_background_color = request.POST.get('primary_background_color')
        theme.secondary_background_color = request.POST.get('secondary_background_color')
        theme.nav_background_color = request.POST.get('nav_background_color')
        theme.text_color = request.POST.get('text_color')
        theme.accent_color = request.POST.get('accent_color')
        theme.user_message_color = request.POST.get('user_message_color')
        theme.bot_message_color = request.POST.get('bot_message_color')
        theme.bot_icon_background_color = request.POST.get('bot_icon_background_color')
        theme.gradient_start_color = request.POST.get('gradient_start_color')
        theme.gradient_end_color = request.POST.get('gradient_end_color')
        theme.font_family = request.POST.get('font_family')
        theme.navbar_text_color = request.POST.get('navbar_text_color')
        theme.button_padding = request.POST.get('button_padding')
        theme.button_border_radius = request.POST.get('button_border_radius')
        theme.button_font_size = request.POST.get('button_font_size')
        theme.message_animation_duration = request.POST.get('message_animation_duration')
        theme.message_icon_size = request.POST.get('message_icon_size')
        theme.suggestion_button_padding = request.POST.get('suggestion_button_padding')
        theme.suggestion_button_border_radius = request.POST.get('suggestion_button_border_radius')
        theme.save()
        return JsonResponse({'success': 'Theme updated successfully'})
    return JsonResponse({'error': 'Invalid request'}, status=400)

# View to display chatbot settings page for the admin to edit theme (via form)
def chatbot_settings_view(request):
    theme = ChatbotTheme.objects.first()  # Assuming only one default theme
    if request.method == 'POST':
        if theme:
            theme.primary_background_color = request.POST.get('primary_background_color')
            theme.secondary_background_color = request.POST.get('secondary_background_color')
            theme.nav_background_color = request.POST.get('nav_background_color')
            theme.text_color = request.POST.get('text_color')
            theme.accent_color = request.POST.get('accent_color')
            theme.user_message_color = request.POST.get('user_message_color')
            theme.bot_message_color = request.POST.get('bot_message_color')
            theme.bot_icon_background_color = request.POST.get('bot_icon_background_color')
            theme.gradient_start_color = request.POST.get('gradient_start_color')
            theme.gradient_end_color = request.POST.get('gradient_end_color')
            theme.font_family = request.POST.get('font_family')
            theme.navbar_text_color = request.POST.get('navbar_text_color')
            theme.button_padding = request.POST.get('button_padding')
            theme.button_border_radius = request.POST.get('button_border_radius')
            theme.button_font_size = request.POST.get('button_font_size')
            theme.message_animation_duration = request.POST.get('message_animation_duration')
            theme.message_icon_size = request.POST.get('message_icon_size')
            theme.suggestion_button_padding = request.POST.get('suggestion_button_padding')
            theme.suggestion_button_border_radius = request.POST.get('suggestion_button_border_radius')
            theme.save()
            return redirect('admin_panel:chatbot_settings')
        else:
            # Create a new theme if it doesn't exist
            ChatbotTheme.objects.create(
                primary_background_color=request.POST.get('primary_background_color'),
                secondary_background_color=request.POST.get('secondary_background_color'),
                nav_background_color=request.POST.get('nav_background_color'),
                text_color=request.POST.get('text_color'),
                accent_color=request.POST.get('accent_color'),
                user_message_color=request.POST.get('user_message_color'),
                bot_message_color=request.POST.get('bot_message_color'),
                bot_icon_background_color=request.POST.get('bot_icon_background_color'),
                gradient_start_color=request.POST.get('gradient_start_color'),
                gradient_end_color=request.POST.get('gradient_end_color'),
                font_family=request.POST.get('font_family'),
                navbar_text_color=request.POST.get('navbar_text_color'),
                button_padding=request.POST.get('button_padding'),
                button_border_radius=request.POST.get('button_border_radius'),
                button_font_size=request.POST.get('button_font_size'),
                message_animation_duration=request.POST.get('message_animation_duration'),
                message_icon_size=request.POST.get('message_icon_size'),
                suggestion_button_padding=request.POST.get('suggestion_button_padding'),
                suggestion_button_border_radius=request.POST.get('suggestion_button_border_radius'),
            )
            return redirect('admin_panel:chatbot_settings')

    context = {'theme': theme}
    return render(request, 'admin_panel/chatbot_settings.html', context)
