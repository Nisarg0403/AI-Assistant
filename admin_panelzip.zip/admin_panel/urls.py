from django.urls import path
from . import views

app_name = 'admin_panel'

urlpatterns = [
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('manage-faqs/', views.manage_faqs, name='manage_faqs'),
    path('edit-faq/', views.edit_faq, name='edit_faq'),
    path('delete-faq/<int:faq_id>/', views.delete_faq, name='delete_faq'),
    path('chatbot-settings/', views.chatbot_settings_view, name='chatbot_settings'),  # New URL for chatbot settings
    path('get-theme-settings/', views.get_theme_settings, name='get_theme_settings'),  # View to fetch current theme
    path('update-theme-settings/', views.update_theme_settings, name='update_theme_settings'),  # Update theme settings

]
